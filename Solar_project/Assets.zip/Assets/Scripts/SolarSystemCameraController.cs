using UnityEngine;

namespace SolarSystemAssignment
{
    public class SolarSystemCameraController : MonoBehaviour
    {
        [SerializeField] private float positionLerpSpeed = 4f;
        [SerializeField] private float rotationLerpSpeed = 5f;
        [SerializeField] private Vector3 fallbackDirection = new Vector3(0.5f, 0.2f, -1f);

        private Vector3 overviewPosition;
        private Quaternion overviewRotation;
        private Transform focusTarget;
        private float focusDistance = 4f;
        private float focusHeight = 1.4f;
        private bool overviewStored;

        public void StoreOverviewPose()
        {
            overviewPosition = transform.position;
            overviewRotation = transform.rotation;
            overviewStored = true;
        }

        public void FocusOn(SolarSelectable selectable)
        {
            if (selectable == null)
            {
                return;
            }

            if (!overviewStored)
            {
                StoreOverviewPose();
            }

            focusTarget = selectable.transform;
            focusDistance = selectable.FocusDistance;
            focusHeight = selectable.FocusHeight;
        }

        public void ReturnToOverview()
        {
            focusTarget = null;
        }

        private void Start()
        {
            StoreOverviewPose();
        }

        private void LateUpdate()
        {
            if (!overviewStored)
            {
                return;
            }

            Vector3 desiredPosition;
            Quaternion desiredRotation;

            if (focusTarget != null)
            {
                Vector3 direction = overviewPosition - focusTarget.position;
                direction = new Vector3(direction.x, 0f, direction.z);

                if (direction.sqrMagnitude < 0.01f)
                {
                    direction = new Vector3(fallbackDirection.x, 0f, fallbackDirection.z);
                }

                direction.Normalize();
                desiredPosition = focusTarget.position + direction * focusDistance + Vector3.up * focusHeight;

                Vector3 lookDirection = focusTarget.position - desiredPosition;
                if (lookDirection.sqrMagnitude < 0.01f)
                {
                    lookDirection = Vector3.forward;
                }

                desiredRotation = Quaternion.LookRotation(lookDirection.normalized, Vector3.up);
            }
            else
            {
                desiredPosition = overviewPosition;
                desiredRotation = overviewRotation;
            }

            float positionT = 1f - Mathf.Exp(-positionLerpSpeed * Time.deltaTime);
            float rotationT = 1f - Mathf.Exp(-rotationLerpSpeed * Time.deltaTime);

            transform.position = Vector3.Lerp(transform.position, desiredPosition, positionT);
            transform.rotation = Quaternion.Slerp(transform.rotation, desiredRotation, rotationT);
        }
    }
}

using UnityEngine;

namespace SolarSystemAssignment
{
    public class OrbitMotion : MonoBehaviour
    {
        [SerializeField] private Transform orbitCenter;
        [SerializeField] private float orbitRadius = 5f;
        [SerializeField] private float orbitSpeed = 10f;
        [SerializeField] private float selfRotationSpeed = 30f;
        [SerializeField] private Vector3 orbitAxis = Vector3.up;
        [SerializeField] private float initialAngle;

        private float currentAngle;

        public void Configure(
            Transform newOrbitCenter,
            float newOrbitRadius,
            float newOrbitSpeed,
            float newSelfRotationSpeed,
            float newInitialAngle)
        {
            orbitCenter = newOrbitCenter;
            orbitRadius = Mathf.Max(0f, newOrbitRadius);
            orbitSpeed = newOrbitSpeed;
            selfRotationSpeed = newSelfRotationSpeed;
            initialAngle = newInitialAngle;
            currentAngle = initialAngle;
            UpdateOrbitPosition();
        }

        private void Start()
        {
            currentAngle = initialAngle;
            UpdateOrbitPosition();
        }

        private void Update()
        {
            if (orbitCenter != null)
            {
                currentAngle += orbitSpeed * Time.deltaTime;

                if (currentAngle >= 360f || currentAngle <= -360f)
                {
                    currentAngle %= 360f;
                }

                UpdateOrbitPosition();
            }

            if (Mathf.Abs(selfRotationSpeed) > Mathf.Epsilon)
            {
                transform.Rotate(Vector3.up, selfRotationSpeed * Time.deltaTime, Space.Self);
            }
        }

        private void UpdateOrbitPosition()
        {
            if (orbitCenter == null)
            {
                return;
            }

            Vector3 axis = orbitAxis.sqrMagnitude > 0.001f ? orbitAxis.normalized : Vector3.up;
            Quaternion rotation = Quaternion.AngleAxis(currentAngle, axis);
            Vector3 offset = rotation * (Vector3.forward * orbitRadius);
            transform.position = orbitCenter.position + offset;
        }
    }
}

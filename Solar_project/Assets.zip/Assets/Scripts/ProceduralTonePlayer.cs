using UnityEngine;

namespace SolarSystemAssignment
{
    [RequireComponent(typeof(AudioSource))]
    public class ProceduralTonePlayer : MonoBehaviour
    {
        [SerializeField] private float selectFrequency = 660f;
        [SerializeField] private float returnFrequency = 440f;
        [SerializeField] private float duration = 0.12f;
        [SerializeField] private float volume = 0.14f;

        private AudioSource audioSource;
        private AudioClip selectClip;
        private AudioClip returnClip;

        private void Awake()
        {
            audioSource = GetComponent<AudioSource>();
            audioSource.playOnAwake = false;
            audioSource.loop = false;
            audioSource.spatialBlend = 0f;

            selectClip = CreateToneClip("SelectTone", selectFrequency);
            returnClip = CreateToneClip("ReturnTone", returnFrequency);
        }

        public void PlaySelectTone()
        {
            PlayClip(selectClip);
        }

        public void PlayReturnTone()
        {
            PlayClip(returnClip);
        }

        private void PlayClip(AudioClip clip)
        {
            if (audioSource == null || clip == null)
            {
                return;
            }

            audioSource.Stop();
            audioSource.clip = clip;
            audioSource.Play();
        }

        private AudioClip CreateToneClip(string clipName, float frequency)
        {
            int sampleRate = 44100;
            int sampleCount = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[sampleCount];

            for (int i = 0; i < sampleCount; i++)
            {
                float progress = i / (float)sampleCount;
                float envelope = Mathf.SmoothStep(1f, 0f, progress);
                float wave = Mathf.Sin(2f * Mathf.PI * frequency * i / sampleRate);
                samples[i] = wave * volume * envelope;
            }

            AudioClip clip = AudioClip.Create(clipName, sampleCount, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }
    }
}

using UnityEngine;
using UnityEngine.EventSystems;

namespace SolarSystemAssignment
{
    public class SolarInteractionManager : MonoBehaviour
    {
        public static SolarInteractionManager Instance { get; private set; }

        [SerializeField] private SolarSystemCameraController cameraController;
        [SerializeField] private SolarSystemUI ui;
        [SerializeField] private ProceduralTonePlayer audioPlayer;

        private SolarSelectable[] selectables = new SolarSelectable[0];
        private SolarSelectable currentSelection;

        public void Configure(
            SolarSystemCameraController newCameraController,
            SolarSystemUI newUi,
            ProceduralTonePlayer newAudioPlayer)
        {
            cameraController = newCameraController;
            ui = newUi;
            audioPlayer = newAudioPlayer;
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            RefreshSelectables();
        }

        private void Start()
        {
            cameraController?.StoreOverviewPose();
            ui?.ShowWelcome();
        }

        private void Update()
        {
            if (Input.GetMouseButtonDown(0))
            {
                TrySelectUnderCursor();
            }

            if (currentSelection != null && Input.GetKeyDown(KeyCode.Escape))
            {
                ReturnToOverview();
            }
        }

        public void Select(SolarSelectable selectable)
        {
            if (selectable == null)
            {
                return;
            }

            if (currentSelection == selectable)
            {
                return;
            }

            if (selectables == null || selectables.Length == 0)
            {
                RefreshSelectables();
            }

            currentSelection = selectable;

            for (int i = 0; i < selectables.Length; i++)
            {
                if (selectables[i] != null)
                {
                    selectables[i].SetSelected(selectables[i] == selectable);
                }
            }

            cameraController?.FocusOn(selectable);
            ui?.ShowSelection(selectable.DisplayName, selectable.FunFact);
            audioPlayer?.PlaySelectTone();
        }

        public void ReturnToOverview()
        {
            currentSelection = null;

            if (selectables == null || selectables.Length == 0)
            {
                RefreshSelectables();
            }

            for (int i = 0; i < selectables.Length; i++)
            {
                if (selectables[i] != null)
                {
                    selectables[i].SetSelected(false);
                }
            }

            cameraController?.ReturnToOverview();
            ui?.ShowWelcome();
            audioPlayer?.PlayReturnTone();
        }

        private void RefreshSelectables()
        {
            selectables = FindObjectsOfType<SolarSelectable>();
        }

        private void TrySelectUnderCursor()
        {
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
            {
                return;
            }

            Camera activeCamera = Camera.main;
            if (activeCamera == null && cameraController != null)
            {
                activeCamera = cameraController.GetComponent<Camera>();
            }

            if (activeCamera == null)
            {
                return;
            }

            Ray ray = activeCamera.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit, 500f))
            {
                SolarSelectable selectable = hit.collider.GetComponentInParent<SolarSelectable>();
                if (selectable != null)
                {
                    Select(selectable);
                }
            }
        }
    }
}

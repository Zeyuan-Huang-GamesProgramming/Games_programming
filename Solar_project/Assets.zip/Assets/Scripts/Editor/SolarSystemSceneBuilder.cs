#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using SolarSystemAssignment;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;
using UnityEngine.UI;

namespace SolarSystemAssignment.Editor
{
    public static class SolarSystemSceneBuilder
    {
        private const string ScenePath = "Assets/Scenes/InteractiveSolarSystem.unity";
        private const string MaterialFolder = "Assets/Materials";
        private const string TextureFolder = "Assets/Materials/Textures";

        [MenuItem("Tools/Solar System/Create Interactive Assignment Scene")]
        public static void CreateInteractiveAssignmentScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            {
                return;
            }

            EnsureFolder("Assets/Scenes");
            EnsureFolder(MaterialFolder);
            EnsureFolder(TextureFolder);

            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            ApplySceneLighting();

            GameObject root = new GameObject("Interactive Solar System");

            SolarSystemCameraController cameraController = CreateCamera(root.transform);
            CreateEventSystem();
            SolarSystemUI ui = CreateUi(root.transform);
            SolarInteractionManager interactionManager = CreateInteractionManager(root.transform, cameraController, ui);

            GameObject sun = CreatePlanet(
                root.transform,
                "Sun",
                3.6f,
                Vector3.zero,
                CreateSunSurfaceMaterial("Sun.mat"),
                "Sun",
                "The Sun is a giant star. It gives light and warmth to all the planets.",
                8.5f,
                2f,
                new Color(1f, 0.9f, 0.35f),
                false);
            CreateSunGlow(sun.transform);

            OrbitMotion sunMotion = sun.AddComponent<OrbitMotion>();
            sunMotion.Configure(null, 0f, 0f, 12f, 0f);

            Light sunLight = sun.AddComponent<Light>();
            sunLight.type = LightType.Point;
            sunLight.range = 56f;
            sunLight.intensity = 2.25f;
            sunLight.color = new Color(1f, 0.87f, 0.62f);

            GameObject earth = CreatePlanet(
                root.transform,
                "Earth",
                1.35f,
                new Vector3(0f, 0f, 10f),
                CreateEarthMaterial("Earth.mat"),
                "Earth",
                "Earth is our home. It is the only planet we know with oceans, clouds, and life.",
                4.8f,
                1.7f,
                new Color(0.35f, 0.85f, 1f),
                true);
            CreateEarthVisuals(earth.transform);

            OrbitMotion earthMotion = earth.AddComponent<OrbitMotion>();
            earthMotion.Configure(sun.transform, 10f, 10f, 70f, 25f);

            GameObject moon = CreatePlanet(
                root.transform,
                "Moon",
                0.45f,
                new Vector3(0f, 0f, 13f),
                CreateMoonMaterial("Moon.mat"),
                "Moon",
                "The Moon goes around Earth. It shines because sunlight bounces off its rocky surface.",
                2.2f,
                0.7f,
                new Color(0.95f, 0.95f, 1f),
                true);

            OrbitMotion moonMotion = moon.AddComponent<OrbitMotion>();
            moonMotion.Configure(earth.transform, 2.8f, 35f, 50f, 140f);

            GameObject mars = CreatePlanet(
                root.transform,
                "Mars",
                0.95f,
                new Vector3(0f, 0f, 15f),
                CreateMarsMaterial("Mars.mat"),
                "Mars",
                "Mars is called the red planet. It has giant volcanoes and dusty storms.",
                3.8f,
                1.2f,
                new Color(1f, 0.65f, 0.35f),
                false);

            OrbitMotion marsMotion = mars.AddComponent<OrbitMotion>();
            marsMotion.Configure(sun.transform, 15f, 6f, 45f, 220f);

            CreateComet(root.transform, sun.transform);

            interactionManager.ReturnToOverview();
            Selection.activeGameObject = root;

            EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(), ScenePath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            EditorUtility.DisplayDialog(
                "Interactive Solar System Ready",
                "Scene created at Assets/Scenes/InteractiveSolarSystem.unity.\n\nPress Play, then click Earth or Moon to demo the interaction.",
                "OK");
        }

        private static void ApplySceneLighting()
        {
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.04f, 0.045f, 0.07f);
            RenderSettings.fog = false;

            GameObject directionalLight = new GameObject("Directional Light");
            Light light = directionalLight.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 0.18f;
            light.color = new Color(0.52f, 0.58f, 0.72f);
            directionalLight.transform.rotation = Quaternion.Euler(35f, -25f, 0f);
        }

        private static SolarSystemCameraController CreateCamera(Transform parent)
        {
            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            cameraObject.transform.SetParent(parent);
            cameraObject.transform.position = new Vector3(0f, 7f, -24f);
            cameraObject.transform.rotation = Quaternion.Euler(12f, 0f, 0f);

            Camera camera = cameraObject.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.02f, 0.03f, 0.08f);
            camera.nearClipPlane = 0.1f;
            camera.farClipPlane = 200f;

            cameraObject.AddComponent<AudioListener>();

            return cameraObject.AddComponent<SolarSystemCameraController>();
        }

        private static SolarInteractionManager CreateInteractionManager(
            Transform parent,
            SolarSystemCameraController cameraController,
            SolarSystemUI ui)
        {
            GameObject managerObject = new GameObject("Solar Interaction Manager");
            managerObject.transform.SetParent(parent);

            ProceduralTonePlayer tonePlayer = managerObject.AddComponent<ProceduralTonePlayer>();
            SolarInteractionManager manager = managerObject.AddComponent<SolarInteractionManager>();
            manager.Configure(cameraController, ui, tonePlayer);
            return manager;
        }

        private static SolarSystemUI CreateUi(Transform parent)
        {
            Font font = LoadBuiltinFont();

            GameObject canvasObject = new GameObject("Solar System UI");
            canvasObject.transform.SetParent(parent);
            Canvas canvas = canvasObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvasObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.matchWidthOrHeight = 1f;
            canvasObject.AddComponent<GraphicRaycaster>();

            GameObject panelObject = CreateUiObject("Info Panel", canvasObject.transform, new Vector2(0.5f, 0f), new Vector2(900f, 200f), new Vector2(0f, 22f));
            Image panelImage = panelObject.AddComponent<Image>();
            panelImage.color = new Color(0f, 0f, 0f, 0.6f);

            Text titleText = CreateText(
                "Title",
                panelObject.transform,
                font,
                28,
                FontStyle.Bold,
                TextAnchor.UpperLeft,
                new Vector2(0f, 1f),
                new Vector2(820f, 36f),
                new Vector2(18f, -18f),
                Color.white);

            Text factText = CreateText(
                "Fact",
                panelObject.transform,
                font,
                20,
                FontStyle.Normal,
                TextAnchor.UpperLeft,
                new Vector2(0f, 1f),
                new Vector2(820f, 90f),
                new Vector2(18f, -58f),
                new Color(0.94f, 0.96f, 1f));

            Text hintText = CreateText(
                "Hint",
                panelObject.transform,
                font,
                16,
                FontStyle.Italic,
                TextAnchor.LowerLeft,
                new Vector2(0f, 0f),
                new Vector2(820f, 28f),
                new Vector2(18f, 14f),
                new Color(0.72f, 0.86f, 1f));

            GameObject instructionObject = CreateUiObject("Instruction", canvasObject.transform, new Vector2(0.5f, 1f), new Vector2(430f, 48f), new Vector2(0f, -28f));
            Text instructionText = instructionObject.AddComponent<Text>();
            instructionText.font = font;
            instructionText.fontSize = 22;
            instructionText.fontStyle = FontStyle.Bold;
            instructionText.alignment = TextAnchor.MiddleCenter;
            instructionText.color = new Color(1f, 0.95f, 0.72f);
            instructionText.text = "Click Earth or Moon";

            GameObject buttonObject = CreateUiObject("Return Button", canvasObject.transform, new Vector2(1f, 1f), new Vector2(240f, 46f), new Vector2(-90f, -34f));
            Image buttonImage = buttonObject.AddComponent<Image>();
            buttonImage.color = new Color(0.2f, 0.34f, 0.58f, 0.95f);
            Button returnButton = buttonObject.AddComponent<Button>();
            ColorBlock colors = returnButton.colors;
            colors.normalColor = buttonImage.color;
            colors.highlightedColor = new Color(0.28f, 0.45f, 0.74f, 1f);
            colors.pressedColor = new Color(0.15f, 0.24f, 0.4f, 1f);
            returnButton.colors = colors;

            Text buttonText = CreateText(
                "Label",
                buttonObject.transform,
                font,
                16,
                FontStyle.Bold,
                TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0.5f),
                new Vector2(240f, 46f),
                Vector2.zero,
                Color.white);
            buttonText.text = "Back to Solar System";

            SolarSystemUI ui = canvasObject.AddComponent<SolarSystemUI>();
            ui.Initialize(titleText, factText, hintText, returnButton);
            return ui;
        }

        private static Font LoadBuiltinFont()
        {
            Font font = null;

            try
            {
                font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            }
            catch
            {
                // Older or different Unity installs may expose a different built-in font name.
            }

            if (font == null)
            {
                try
                {
                    font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                }
                catch
                {
                    // Ignore and fall through to the explicit error below.
                }
            }

            if (font == null)
            {
                throw new MissingReferenceException("Could not load a built-in UI font. Tried LegacyRuntime.ttf and Arial.ttf.");
            }

            return font;
        }

        private static void CreateEventSystem()
        {
            if (UnityEngine.Object.FindObjectOfType<EventSystem>() != null)
            {
                return;
            }

            GameObject eventSystemObject = new GameObject("EventSystem");
            eventSystemObject.AddComponent<EventSystem>();
            eventSystemObject.AddComponent<StandaloneInputModule>();
        }

        private static GameObject CreatePlanet(
            Transform parent,
            string objectName,
            float scale,
            Vector3 position,
            Material material,
            string displayName,
            string fact,
            float focusDistance,
            float focusHeight,
            Color highlight,
            bool clickable)
        {
            GameObject planet = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            planet.name = objectName;
            planet.transform.SetParent(parent);
            planet.transform.position = position;
            planet.transform.localScale = Vector3.one * scale;

            Renderer renderer = planet.GetComponent<Renderer>();
            renderer.sharedMaterial = material;

            if (clickable)
            {
                SolarSelectable selectable = planet.AddComponent<SolarSelectable>();
                selectable.Configure(displayName, fact, focusDistance, focusHeight, highlight, 0.08f);
            }

            return planet;
        }

        private static void CreateComet(Transform parent, Transform orbitCenter)
        {
            GameObject comet = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            comet.name = "Comet";
            comet.transform.SetParent(parent);
            comet.transform.localScale = Vector3.one * 0.28f;

            Renderer renderer = comet.GetComponent<Renderer>();
            renderer.sharedMaterial = CreateMaterial(
                "Comet.mat",
                new Color(0.85f, 0.95f, 1f),
                new Color(0.2f, 0.35f, 0.4f));

            OrbitMotion motion = comet.AddComponent<OrbitMotion>();
            motion.Configure(orbitCenter, 20f, 22f, 140f, 300f);

            TrailRenderer trail = comet.AddComponent<TrailRenderer>();
            trail.time = 1.4f;
            trail.startWidth = 0.16f;
            trail.endWidth = 0.02f;
            trail.material = CreateTrailMaterial("CometTrail.mat", new Color(0.9f, 0.95f, 1f, 1f));
            trail.startColor = new Color(0.85f, 0.95f, 1f, 0.9f);
            trail.endColor = new Color(0.85f, 0.95f, 1f, 0f);
        }

        private static void CreateSunGlow(Transform sunTransform)
        {
            GameObject glow = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            glow.name = "Sun Glow";
            glow.transform.SetParent(sunTransform, false);
            glow.transform.localPosition = Vector3.zero;
            glow.transform.localScale = Vector3.one * 1.035f;

            Collider glowCollider = glow.GetComponent<Collider>();
            if (glowCollider != null)
            {
                UnityEngine.Object.DestroyImmediate(glowCollider);
            }

            Renderer renderer = glow.GetComponent<Renderer>();
            renderer.sharedMaterial = CreateTransparentTextureMaterial(
                "SunGlow.mat",
                new Color(1f, 0.74f, 0.22f, 0.07f),
                null);
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
        }

        private static void CreateEarthVisuals(Transform earthTransform)
        {
            CreateEarthCloudLayer(earthTransform);
            CreateEarthAtmosphere(earthTransform);
        }

        private static void CreateEarthCloudLayer(Transform earthTransform)
        {
            GameObject clouds = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            clouds.name = "Earth Clouds";
            clouds.transform.SetParent(earthTransform, false);
            clouds.transform.localPosition = Vector3.zero;
            clouds.transform.localScale = Vector3.one * 1.018f;

            Collider collider = clouds.GetComponent<Collider>();
            if (collider != null)
            {
                UnityEngine.Object.DestroyImmediate(collider);
            }

            Renderer renderer = clouds.GetComponent<Renderer>();
            renderer.sharedMaterial = CreateTransparentTextureMaterial(
                "EarthClouds.mat",
                new Color(1f, 1f, 1f, 0.34f),
                CreateEarthCloudTexture("EarthClouds.asset"));
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;

            OrbitMotion cloudSpin = clouds.AddComponent<OrbitMotion>();
            cloudSpin.Configure(null, 0f, 0f, 18f, 0f);
        }

        private static void CreateEarthAtmosphere(Transform earthTransform)
        {
            GameObject atmosphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            atmosphere.name = "Earth Atmosphere";
            atmosphere.transform.SetParent(earthTransform, false);
            atmosphere.transform.localPosition = Vector3.zero;
            atmosphere.transform.localScale = Vector3.one * 1.035f;

            Collider collider = atmosphere.GetComponent<Collider>();
            if (collider != null)
            {
                UnityEngine.Object.DestroyImmediate(collider);
            }

            Renderer renderer = atmosphere.GetComponent<Renderer>();
            renderer.sharedMaterial = CreateTransparentTextureMaterial(
                "EarthAtmosphere.mat",
                new Color(0.45f, 0.75f, 1f, 0.025f),
                null);
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
        }

        private static Material CreateMaterial(string fileName, Color baseColor, Color emissionColor)
        {
            string path = Path.Combine(MaterialFolder, fileName).Replace("\\", "/");
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);

            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit");
                if (shader == null)
                {
                    shader = Shader.Find("Standard");
                }

                material = new Material(shader);
                AssetDatabase.CreateAsset(material, path);
            }

            if (material.HasProperty("_BaseColor"))
            {
                material.SetColor("_BaseColor", baseColor);
            }
            else if (material.HasProperty("_Color"))
            {
                material.SetColor("_Color", baseColor);
            }

            if (material.HasProperty("_EmissionColor"))
            {
                material.EnableKeyword("_EMISSION");
                material.SetColor("_EmissionColor", emissionColor);
            }

            return material;
        }

        private static Material CreateSunSurfaceMaterial(string fileName)
        {
            Material material = GetOrCreateMaterial(fileName, "Unlit/Texture", "Universal Render Pipeline/Unlit", "Standard");
            Texture2D surfaceTexture = CreateSunSurfaceTexture("SunSurface.asset");
            SetMainTexture(material, surfaceTexture);
            SetMaterialColor(material, new Color(1f, 0.94f, 0.84f));

            if (material.HasProperty("_EmissionColor"))
            {
                material.EnableKeyword("_EMISSION");
                material.SetColor("_EmissionColor", new Color(0.8f, 0.38f, 0.1f));
            }

            SetMaterialMetallic(material, 0f);
            SetMaterialSmoothness(material, 0f);

            return material;
        }

        private static Material CreateAdditiveGlowMaterial(string fileName, Color tintColor)
        {
            string path = Path.Combine(MaterialFolder, fileName).Replace("\\", "/");
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);

            if (material == null)
            {
                Shader shader = Shader.Find("Particles/Additive");
                if (shader == null)
                {
                    shader = Shader.Find("Legacy Shaders/Particles/Additive");
                }
                if (shader == null)
                {
                    shader = Shader.Find("Sprites/Default");
                }

                material = new Material(shader);
                AssetDatabase.CreateAsset(material, path);
            }

            if (material.HasProperty("_TintColor"))
            {
                material.SetColor("_TintColor", tintColor);
            }

            if (material.HasProperty("_Color"))
            {
                material.SetColor("_Color", tintColor);
            }

            return material;
        }

        private static Material CreateTrailMaterial(string fileName, Color tintColor)
        {
            string path = Path.Combine(MaterialFolder, fileName).Replace("\\", "/");
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);

            if (material == null)
            {
                Shader shader = Shader.Find("Sprites/Default");
                if (shader == null)
                {
                    shader = Shader.Find("Standard");
                }

                material = new Material(shader);
                AssetDatabase.CreateAsset(material, path);
            }

            if (material.HasProperty("_Color"))
            {
                material.SetColor("_Color", tintColor);
            }

            return material;
        }

        private static Material CreateEarthMaterial(string fileName)
        {
            Material material = GetOrCreateMaterial(fileName, "Universal Render Pipeline/Lit", "Standard");
            Texture2D surfaceTexture = CreateEarthSurfaceTexture("EarthSurface.asset");
            SetMainTexture(material, surfaceTexture);
            SetMaterialColor(material, Color.white);
            SetMaterialMetallic(material, 0.02f);
            SetMaterialSmoothness(material, 0.08f);
            return material;
        }

        private static Material CreateMoonMaterial(string fileName)
        {
            Material material = GetOrCreateMaterial(fileName, "Universal Render Pipeline/Lit", "Standard");
            Texture2D surfaceTexture = CreateMoonSurfaceTexture("MoonSurface.asset");
            SetMainTexture(material, surfaceTexture);
            SetMaterialColor(material, Color.white);
            SetMaterialMetallic(material, 0f);
            SetMaterialSmoothness(material, 0.02f);
            return material;
        }

        private static Material CreateMarsMaterial(string fileName)
        {
            Material material = GetOrCreateMaterial(fileName, "Universal Render Pipeline/Lit", "Standard");
            Texture2D surfaceTexture = CreateMarsSurfaceTexture("MarsSurface.asset");
            SetMainTexture(material, surfaceTexture);
            SetMaterialColor(material, Color.white);
            SetMaterialMetallic(material, 0f);
            SetMaterialSmoothness(material, 0.04f);
            return material;
        }

        private static Material CreateTransparentTextureMaterial(string fileName, Color tintColor, Texture2D texture)
        {
            Material material = GetOrCreateMaterial(
                fileName,
                "Legacy Shaders/Transparent/Diffuse",
                "Sprites/Default",
                "Unlit/Transparent");

            SetMainTexture(material, texture);
            SetMaterialColor(material, tintColor);

            if (material.HasProperty("_TintColor"))
            {
                material.SetColor("_TintColor", tintColor);
            }

            return material;
        }

        private static Material GetOrCreateMaterial(string fileName, params string[] shaderCandidates)
        {
            string path = Path.Combine(MaterialFolder, fileName).Replace("\\", "/");
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            Shader shader = FindShader(shaderCandidates);

            if (material == null)
            {
                material = new Material(shader);
                AssetDatabase.CreateAsset(material, path);
            }
            else if (shader != null && material.shader != shader)
            {
                material.shader = shader;
            }

            return material;
        }

        private static Shader FindShader(params string[] shaderCandidates)
        {
            for (int i = 0; i < shaderCandidates.Length; i++)
            {
                Shader shader = Shader.Find(shaderCandidates[i]);
                if (shader != null)
                {
                    return shader;
                }
            }

            Shader fallback = Shader.Find("Standard");
            if (fallback != null)
            {
                return fallback;
            }

            throw new MissingReferenceException("Could not find a supported shader for the generated solar system materials.");
        }

        private static void SetMainTexture(Material material, Texture2D texture)
        {
            if (material == null || texture == null)
            {
                return;
            }

            if (material.HasProperty("_BaseMap"))
            {
                material.SetTexture("_BaseMap", texture);
            }

            if (material.HasProperty("_MainTex"))
            {
                material.SetTexture("_MainTex", texture);
            }
        }

        private static void SetMaterialColor(Material material, Color color)
        {
            if (material.HasProperty("_BaseColor"))
            {
                material.SetColor("_BaseColor", color);
            }

            if (material.HasProperty("_Color"))
            {
                material.SetColor("_Color", color);
            }
        }

        private static void SetMaterialMetallic(Material material, float metallic)
        {
            if (material.HasProperty("_Metallic"))
            {
                material.SetFloat("_Metallic", metallic);
            }
        }

        private static void SetMaterialSmoothness(Material material, float smoothness)
        {
            if (material.HasProperty("_Smoothness"))
            {
                material.SetFloat("_Smoothness", smoothness);
            }

            if (material.HasProperty("_Glossiness"))
            {
                material.SetFloat("_Glossiness", smoothness);
            }
        }

        private static Texture2D CreateSunSurfaceTexture(string fileName)
        {
            return CreateTextureAsset(fileName, 1024, 512, (u, v) =>
            {
                Vector3 direction = GetSphereDirection(u, v);
                float plasma = SampleFractalNoise(direction, 10f, 1.7f, 5, 0.55f);
                float cells = SampleRidgedNoise(direction, 18f, 7.3f, 3);
                float warmth = Mathf.Clamp01(plasma * 0.72f + cells * 0.28f);

                Color darkOrange = new Color(0.94f, 0.33f, 0.04f);
                Color orange = new Color(1f, 0.62f, 0.08f);
                Color yellow = new Color(1f, 0.9f, 0.38f);

                Color color = Color.Lerp(darkOrange, orange, warmth);
                color = Color.Lerp(color, yellow, Mathf.SmoothStep(0.58f, 1f, warmth));

                float sunSpotMask = SampleRidgedNoise(direction, 46f, 21.4f, 2);
                if (sunSpotMask > 0.86f)
                {
                    color = Color.Lerp(color, new Color(0.74f, 0.26f, 0.03f), 0.35f);
                }

                return color;
            });
        }

        private static Texture2D CreateEarthSurfaceTexture(string fileName)
        {
            return CreateTextureAsset(fileName, 1024, 512, (u, v) =>
            {
                Vector3 direction = GetSphereDirection(u, v);
                float continents = SampleFractalNoise(direction, 2.1f, 4.2f, 4, 0.56f);
                float ridges = SampleRidgedNoise(direction, 6.6f, 10.8f, 3);
                float landNoise = continents * 0.78f + ridges * 0.22f - Mathf.Abs(direction.y) * 0.08f;
                float landBlend = Mathf.SmoothStep(0.5f, 0.58f, landNoise);

                float oceanNoise = SampleFractalNoise(direction, 8f, 1.5f, 3, 0.55f);
                Color deepOcean = new Color(0.03f, 0.13f, 0.34f);
                Color shallowOcean = new Color(0.08f, 0.38f, 0.64f);
                Color ocean = Color.Lerp(deepOcean, shallowOcean, Mathf.Pow(oceanNoise, 1.4f));

                float biome = SampleFractalNoise(direction, 5.2f, 14.1f, 3, 0.52f);
                float mountains = SampleRidgedNoise(direction, 14f, 9.7f, 4);
                Color lushLand = new Color(0.18f, 0.43f, 0.16f);
                Color dryLand = new Color(0.5f, 0.38f, 0.18f);
                float dryness = Mathf.Clamp01(biome * 0.9f + Mathf.Abs(direction.y) * 0.22f - 0.16f);
                Color land = Color.Lerp(lushLand, dryLand, dryness);
                land = Color.Lerp(land, new Color(0.58f, 0.54f, 0.5f), mountains * landBlend * 0.65f);

                Color color = Color.Lerp(ocean, land, landBlend);
                float ice = Mathf.SmoothStep(0.76f, 0.93f, Mathf.Abs(direction.y));
                color = Color.Lerp(color, new Color(0.94f, 0.97f, 1f), ice * 0.92f);
                return color;
            });
        }

        private static Texture2D CreateEarthCloudTexture(string fileName)
        {
            return CreateTextureAsset(fileName, 1024, 512, (u, v) =>
            {
                Vector3 direction = GetSphereDirection(u, v);
                float cloudShape = SampleFractalNoise(direction, 11f, 30.5f, 5, 0.58f);
                float cloudDetail = SampleRidgedNoise(direction, 23f, 12.7f, 3);
                float alpha = Mathf.SmoothStep(0.69f, 0.84f, cloudShape * 0.74f + cloudDetail * 0.26f) * 0.48f;
                return new Color(1f, 1f, 1f, alpha);
            });
        }

        private static Texture2D CreateMoonSurfaceTexture(string fileName)
        {
            List<CraterData> craters = CreateCraterField(180, 0.03f, 0.11f, 42);

            return CreateTextureAsset(fileName, 1024, 512, (u, v) =>
            {
                Vector3 direction = GetSphereDirection(u, v);
                float baseNoise = SampleFractalNoise(direction, 9f, 5.8f, 4, 0.52f);
                float fineNoise = SampleRidgedNoise(direction, 18f, 17.3f, 3);
                float brightness = Mathf.Lerp(0.38f, 0.7f, baseNoise * 0.75f + fineNoise * 0.25f);

                for (int i = 0; i < craters.Count; i++)
                {
                    float dot = Vector3.Dot(direction, craters[i].Center);
                    if (dot > craters[i].CosRadius)
                    {
                        float t = Mathf.InverseLerp(craters[i].CosRadius, 1f, dot);
                        brightness -= t * craters[i].Depth * 0.34f;

                        if (t < 0.2f)
                        {
                            brightness += (0.2f - t) / 0.2f * craters[i].Depth * 0.26f;
                        }
                    }
                }

                brightness = Mathf.Clamp01(brightness);
                return new Color(brightness * 0.95f, brightness * 0.93f, brightness * 0.9f);
            });
        }

        private static Texture2D CreateMarsSurfaceTexture(string fileName)
        {
            return CreateTextureAsset(fileName, 1024, 512, (u, v) =>
            {
                Vector3 direction = GetSphereDirection(u, v);
                float baseNoise = SampleFractalNoise(direction, 4.4f, 6.3f, 4, 0.55f);
                float dust = SampleRidgedNoise(direction, 12f, 8.2f, 3);
                float value = Mathf.Clamp01(baseNoise * 0.78f + dust * 0.22f);

                Color darkRust = new Color(0.45f, 0.18f, 0.1f);
                Color rust = new Color(0.72f, 0.34f, 0.18f);
                Color brightDust = new Color(0.9f, 0.56f, 0.35f);

                Color color = Color.Lerp(darkRust, rust, value);
                color = Color.Lerp(color, brightDust, Mathf.SmoothStep(0.6f, 1f, value));

                float polarDust = Mathf.SmoothStep(0.88f, 0.97f, Mathf.Abs(direction.y));
                color = Color.Lerp(color, new Color(0.86f, 0.72f, 0.64f), polarDust * 0.45f);
                return color;
            });
        }

        private static Texture2D CreateSoftHaloTexture(string fileName, int size, Color tintColor)
        {
            return CreateTextureAsset(fileName, size, size, (u, v) =>
            {
                float dx = u - 0.5f;
                float dy = v - 0.5f;
                float distance = Mathf.Sqrt(dx * dx + dy * dy) * 2f;
                float alpha = Mathf.Clamp01(1f - distance);
                alpha = alpha * alpha * alpha;
                return new Color(tintColor.r, tintColor.g, tintColor.b, alpha);
            });
        }

        private static Texture2D CreateTextureAsset(string fileName, int width, int height, Func<float, float, Color> pixelGenerator)
        {
            string path = Path.Combine(TextureFolder, fileName).Replace("\\", "/");

            if (AssetDatabase.LoadAssetAtPath<Texture2D>(path) != null)
            {
                AssetDatabase.DeleteAsset(path);
            }

            Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
            texture.name = Path.GetFileNameWithoutExtension(fileName);
            texture.wrapMode = TextureWrapMode.Repeat;
            texture.filterMode = FilterMode.Bilinear;

            Color[] pixels = new Color[width * height];
            for (int y = 0; y < height; y++)
            {
                float v = y / (float)(height - 1);
                for (int x = 0; x < width; x++)
                {
                    float u = x / (float)(width - 1);
                    pixels[y * width + x] = pixelGenerator(u, v);
                }
            }

            texture.SetPixels(pixels);
            texture.Apply();
            AssetDatabase.CreateAsset(texture, path);

            return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }

        private static Vector3 GetSphereDirection(float u, float v)
        {
            float longitude = (u - 0.5f) * Mathf.PI * 2f;
            float latitude = (v - 0.5f) * Mathf.PI;
            float cosLatitude = Mathf.Cos(latitude);

            return new Vector3(
                cosLatitude * Mathf.Cos(longitude),
                Mathf.Sin(latitude),
                cosLatitude * Mathf.Sin(longitude));
        }

        private static float SampleFractalNoise(Vector3 direction, float scale, float seed, int octaves, float persistence)
        {
            float total = 0f;
            float frequency = scale;
            float amplitude = 1f;
            float weight = 0f;

            for (int i = 0; i < octaves; i++)
            {
                total += SampleSphericalNoise(direction, frequency, seed + i * 7.13f) * amplitude;
                weight += amplitude;
                amplitude *= persistence;
                frequency *= 2f;
            }

            return weight > 0f ? total / weight : 0f;
        }

        private static float SampleRidgedNoise(Vector3 direction, float scale, float seed, int octaves)
        {
            float total = 0f;
            float frequency = scale;
            float amplitude = 1f;
            float weight = 0f;

            for (int i = 0; i < octaves; i++)
            {
                float value = SampleSphericalNoise(direction, frequency, seed + i * 5.31f);
                value = 1f - Mathf.Abs(value * 2f - 1f);
                total += value * amplitude;
                weight += amplitude;
                amplitude *= 0.5f;
                frequency *= 2f;
            }

            return weight > 0f ? total / weight : 0f;
        }

        private static float SampleSphericalNoise(Vector3 direction, float scale, float seed)
        {
            float xy = Mathf.PerlinNoise(direction.x * scale + seed, direction.y * scale + seed * 0.71f);
            float yz = Mathf.PerlinNoise(direction.y * scale - seed * 0.37f, direction.z * scale + seed * 1.17f);
            float zx = Mathf.PerlinNoise(direction.z * scale + seed * 0.23f, direction.x * scale - seed * 0.89f);
            return (xy + yz + zx) / 3f;
        }

        private static List<CraterData> CreateCraterField(int count, float minRadius, float maxRadius, int seed)
        {
            System.Random random = new System.Random(seed);
            List<CraterData> craters = new List<CraterData>(count);

            for (int i = 0; i < count; i++)
            {
                Vector3 center = new Vector3(
                    (float)(random.NextDouble() * 2.0 - 1.0),
                    (float)(random.NextDouble() * 2.0 - 1.0),
                    (float)(random.NextDouble() * 2.0 - 1.0)).normalized;

                float t = Mathf.Pow((float)random.NextDouble(), 1.8f);
                float radius = Mathf.Lerp(minRadius, maxRadius, t);
                float depth = Mathf.Lerp(0.08f, 0.3f, (float)random.NextDouble());

                craters.Add(new CraterData(center, radius, depth));
            }

            return craters;
        }

        private readonly struct CraterData
        {
            public CraterData(Vector3 center, float radius, float depth)
            {
                Center = center;
                Radius = radius;
                Depth = depth;
                CosRadius = Mathf.Cos(radius * Mathf.PI);
            }

            public Vector3 Center { get; }
            public float Radius { get; }
            public float Depth { get; }
            public float CosRadius { get; }
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path))
            {
                return;
            }

            string parent = Path.GetDirectoryName(path)?.Replace("\\", "/");
            string folderName = Path.GetFileName(path);

            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent))
            {
                EnsureFolder(parent);
            }

            AssetDatabase.CreateFolder(parent, folderName);
        }

        private static GameObject CreateUiObject(
            string objectName,
            Transform parent,
            Vector2 anchor,
            Vector2 size,
            Vector2 anchoredPosition)
        {
            GameObject uiObject = new GameObject(objectName, typeof(RectTransform));
            uiObject.transform.SetParent(parent, false);

            RectTransform rectTransform = uiObject.GetComponent<RectTransform>();
            rectTransform.anchorMin = anchor;
            rectTransform.anchorMax = anchor;
            rectTransform.pivot = anchor;
            rectTransform.sizeDelta = size;
            rectTransform.anchoredPosition = anchoredPosition;
            return uiObject;
        }

        private static Text CreateText(
            string objectName,
            Transform parent,
            Font font,
            int fontSize,
            FontStyle fontStyle,
            TextAnchor alignment,
            Vector2 anchor,
            Vector2 size,
            Vector2 anchoredPosition,
            Color color)
        {
            GameObject textObject = CreateUiObject(objectName, parent, anchor, size, anchoredPosition);
            Text text = textObject.AddComponent<Text>();
            text.font = font;
            text.fontSize = fontSize;
            text.fontStyle = fontStyle;
            text.alignment = alignment;
            text.color = color;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            return text;
        }
    }
}
#endif

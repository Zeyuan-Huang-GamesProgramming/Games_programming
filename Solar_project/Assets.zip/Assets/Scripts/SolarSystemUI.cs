using UnityEngine;
using UnityEngine.UI;

namespace SolarSystemAssignment
{
    public class SolarSystemUI : MonoBehaviour
    {
        [SerializeField] private Text titleText;
        [SerializeField] private Text factText;
        [SerializeField] private Text hintText;
        [SerializeField] private Button returnButton;

        public void Initialize(Text newTitleText, Text newFactText, Text newHintText, Button newReturnButton)
        {
            titleText = newTitleText;
            factText = newFactText;
            hintText = newHintText;
            returnButton = newReturnButton;
        }

        private void Start()
        {
            if (returnButton != null)
            {
                returnButton.onClick.RemoveListener(HandleReturnButton);
                returnButton.onClick.AddListener(HandleReturnButton);
            }

            ShowWelcome();
        }

        public void ShowWelcome()
        {
            if (titleText != null)
            {
                titleText.text = "Interactive Solar System";
            }

            if (factText != null)
            {
                factText.text = "Click Earth or Moon to zoom in and learn a fun fact.";
            }

            if (hintText != null)
            {
                hintText.text = "Press Escape or click Return to go back to the full solar view.";
            }

            SetReturnButtonVisible(true);
            SetReturnButtonInteractable(false);
        }

        public void ShowSelection(string objectName, string fact)
        {
            if (titleText != null)
            {
                titleText.text = objectName;
            }

            if (factText != null)
            {
                factText.text = fact;
            }

            if (hintText != null)
            {
                hintText.text = "Use Return to look at the whole solar system again.";
            }

            SetReturnButtonVisible(true);
            SetReturnButtonInteractable(true);
        }

        public void SetReturnButtonVisible(bool visible)
        {
            if (returnButton != null)
            {
                returnButton.gameObject.SetActive(visible);
            }
        }

        public void SetReturnButtonInteractable(bool interactable)
        {
            if (returnButton != null)
            {
                returnButton.interactable = interactable;
            }
        }

        private void HandleReturnButton()
        {
            SolarInteractionManager.Instance?.ReturnToOverview();
        }
    }
}

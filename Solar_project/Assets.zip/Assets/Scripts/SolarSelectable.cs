using System.Collections.Generic;
using UnityEngine;

namespace SolarSystemAssignment
{
    [DisallowMultipleComponent]
    public class SolarSelectable : MonoBehaviour
    {
        [SerializeField] private string displayName = "Planet";
        [SerializeField, TextArea(2, 4)] private string funFact = "Click to learn more.";
        [SerializeField] private float focusDistance = 4f;
        [SerializeField] private float focusHeight = 1.4f;
        [SerializeField] private Color highlightColor = new Color(1f, 0.85f, 0.3f);
        [SerializeField] private float pulseScaleAmount = 0.1f;
        [SerializeField] private float pulseSpeed = 5f;

        private readonly List<MaterialState> materialStates = new List<MaterialState>();
        private Vector3 originalScale;
        private bool isSelected;

        public string DisplayName => displayName;
        public string FunFact => funFact;
        public float FocusDistance => focusDistance;
        public float FocusHeight => focusHeight;

        public void Configure(
            string newDisplayName,
            string newFunFact,
            float newFocusDistance,
            float newFocusHeight,
            Color newHighlightColor,
            float newPulseScaleAmount = 0.1f)
        {
            displayName = newDisplayName;
            funFact = newFunFact;
            focusDistance = newFocusDistance;
            focusHeight = newFocusHeight;
            highlightColor = newHighlightColor;
            pulseScaleAmount = newPulseScaleAmount;
        }

        private void Awake()
        {
            originalScale = transform.localScale;
            CacheMaterials();
        }

        private void Update()
        {
            if (!isSelected)
            {
                return;
            }

            float pulse = (Mathf.Sin(Time.time * pulseSpeed) + 1f) * 0.5f;
            transform.localScale = originalScale * (1f + pulse * pulseScaleAmount);

            for (int i = 0; i < materialStates.Count; i++)
            {
                materialStates[i].Apply(highlightColor, pulse);
            }
        }

        private void OnMouseDown()
        {
            if (!enabled)
            {
                return;
            }

            SolarInteractionManager.Instance?.Select(this);
        }

        public void SetSelected(bool selected)
        {
            if (isSelected == selected)
            {
                return;
            }

            isSelected = selected;

            if (!selected)
            {
                transform.localScale = originalScale;

                for (int i = 0; i < materialStates.Count; i++)
                {
                    materialStates[i].Restore();
                }
            }
        }

        private void CacheMaterials()
        {
            materialStates.Clear();
            Renderer[] renderers = GetComponentsInChildren<Renderer>();

            for (int i = 0; i < renderers.Length; i++)
            {
                Material[] materials = renderers[i].materials;

                for (int j = 0; j < materials.Length; j++)
                {
                    if (materials[j] != null)
                    {
                        materialStates.Add(new MaterialState(materials[j]));
                    }
                }
            }
        }

        private sealed class MaterialState
        {
            private readonly Material material;
            private readonly string colorPropertyName;
            private readonly bool hasEmission;
            private readonly Color baseColor;
            private readonly Color baseEmission;

            public MaterialState(Material sourceMaterial)
            {
                material = sourceMaterial;

                if (material.HasProperty("_BaseColor"))
                {
                    colorPropertyName = "_BaseColor";
                }
                else if (material.HasProperty("_Color"))
                {
                    colorPropertyName = "_Color";
                }

                baseColor = !string.IsNullOrEmpty(colorPropertyName)
                    ? material.GetColor(colorPropertyName)
                    : Color.white;

                hasEmission = material.HasProperty("_EmissionColor");
                baseEmission = hasEmission ? material.GetColor("_EmissionColor") : Color.black;

                if (hasEmission)
                {
                    material.EnableKeyword("_EMISSION");
                }
            }

            public void Apply(Color highlight, float pulse)
            {
                if (!string.IsNullOrEmpty(colorPropertyName))
                {
                    material.SetColor(
                        colorPropertyName,
                        Color.Lerp(baseColor, highlight, 0.35f + pulse * 0.45f));
                }

                if (hasEmission)
                {
                    material.SetColor(
                        "_EmissionColor",
                        Color.Lerp(baseEmission, highlight * 0.8f, pulse));
                }
            }

            public void Restore()
            {
                if (!string.IsNullOrEmpty(colorPropertyName))
                {
                    material.SetColor(colorPropertyName, baseColor);
                }

                if (hasEmission)
                {
                    material.SetColor("_EmissionColor", baseEmission);
                }
            }
        }
    }
}
